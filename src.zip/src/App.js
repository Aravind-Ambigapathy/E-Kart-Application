import './App.css';
import Bottommain from './components/Bottommain';
import Navbar from './components/Navbar';
import Secondmain from './components/Secondmain';
import Topmain from './components/Topmain';

function App() {

  return (
    <div className="App">
      <Navbar/><br/><br/><br/><br/><br/>
      <Topmain />
      <Secondmain />
      <Bottommain />
     
    </div>
  );
}

export default App;
