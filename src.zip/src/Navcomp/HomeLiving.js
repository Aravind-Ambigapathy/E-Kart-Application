import React from 'react';
import Navcomp from './Navcomp.css';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';

function HomeLiving() {

  const style = {
    position: 'absolute',
    top: '50%',
    left: '48%',
    transform: 'translate(-50%, -50%)',
    width: 520,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
  };
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  return (
    <div>
      <Button onClick={handleOpen} style={{
        color: 'black',
        fontWeight: 600
      }}>HOME & LIVING</Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <div className='modecontent'>
            <h6> Bed Linen & Furnishing</h6>
            <p>Bedsheets</p>
            <p>Bedding Sets</p>
            <p>Blankets, Quilts & Dohars</p>
            <p>Pillows & Pillow Covers</p>
            <p>Bed Covers</p>
            <p>Diwan Sets</p>
            <p>Chair Pads & Covers</p>
            <p>Sofa Covers</p>
            <p>Flooring</p>
            <p>Carpets</p>
            <p>Floor Mats & Dhurries</p>
            <p>Door Mats</p>
            <hr />
            <h6> Storage</h6>
            <p>Organisers</p>
            <p>Hooks & Holders</p>
            <p>Laundry Bags</p>
          </div> 
          <div className='modecontent'>
            <h6>Bath</h6>
            <p>Bath Towels</p>
            <p>Hand & Face Towels</p>
            <p>Beach Towels</p>
            <p>Towels Set</p>
            <p>Bath Rugs</p>
            <p>Bath Robes</p>
            <p>Bathroom Accessories</p>
            <p>Shower Curtains</p>
            <hr />
            <h6> Lamps & Lighting</h6>
            <p>Floor Lamps</p>
            <p>Ceiling Lamps</p>
            <p>Table Lamps</p>
            <p>Wall Lamps</p>
            <p>Outdoor Lamps</p>
            <p>String Lights</p>
            <p>Mirrors</p>
          </div> 





         

 
        </Box>
      </Modal>
    </div>
  )
}

export default HomeLiving