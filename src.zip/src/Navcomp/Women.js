import React from 'react';
import Navcomp from './Navcomp.css';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';

function Women() {

    const style = {
        position: 'absolute',
        top: '53%',
        left: '33%',
        transform: 'translate(-50%, -50%)',
        width: 520,
        bgcolor: 'background.paper',
        border: '2px solid #000',
        boxShadow: 24,
        p: 4,
    };
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    return (
        <div>
            <Button onClick={handleOpen}
                style={{
                    color: 'black',
                    fontWeight: 600
                }}
            >Women</Button>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style}>
                    <div className='modecontent'>
                        <h6> Western Wear</h6>
                        <p>Dresses</p>
                        <p>Tops</p>
                        <p>Tshirts</p>
                        <p>Jeans</p>
                        <p>Trousers & Capris</p>
                        <p>Co-ords</p>
                        <p>Shrugs</p>
                        <p>Sweaters & Sweatshirts</p>
                        <p>Jackets & Coats</p>
                        <hr />
                        <h6> Sports & Active Wear</h6>
                        <p>Clothing</p>
                        <p>Footwear</p>
                        <p>Sports Accessories</p>
                        <p>Sports Equipment</p>
                        <p>Sarees</p>
                        <hr/>
                        <h6>Belts, Scarves & More</h6>
                    </div>
                    <div className='modecontent'>
                        <h6> Lingerie & Sleepwear</h6>
                        <p>Briefs</p>
                        <p>Shapewear</p>
                        <p>Swimwear</p>
                        <p>Camisoles & Thermals</p>
                        <p>Saree</p>
                        <hr />
                        <h6>Beauty & Personal Care</h6>
                        <p>Premium Beauty</p>
                        <p>Makeup</p>
                        <p>Skincare</p>
                        <p>Shrugs</p>
                        <p>Lipsticks</p>
                        <p>Fragrances</p>
                        <hr />
                        <h6>Kurtas & Suits</h6>
                        <p>Ethnic Wear</p>
                        <p>Leggings, Salwars & Churidars</p>
                        <p>Skirts & Palazzos</p>
                    </div>


                </Box>
            </Modal>
        </div>
    )
}

export default Women