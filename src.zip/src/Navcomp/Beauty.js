import React from 'react';
import Navcomp from './Navcomp.css';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';

function Beauty() {

    const style = {
        position: 'absolute',
        top: '37%',
        left: '64%',
        transform: 'translate(-50%, -50%)',
        width: 650,
        bgcolor: 'background.paper',
        border: '2px solid #000',
        boxShadow: 24,
        p: 4,
    };
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    return (
        <div>
            <Button onClick={handleOpen} style={{
                color: 'black',
                fontWeight: 600
            }}>BEAUTY</Button>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style}>
                    <div className='modecontent'>
                        <h6>Makeup</h6>
                        <p>Lipstick</p>
                        <p>Lip Gloss</p>
                        <p>Lip Liner</p>
                        <p>Mascara</p>
                        <p>Eyeliner</p>
                        <p>Kajal</p>
                        <p>Eyeshadow</p>
                        <p>Foundation</p>
                        <p>Primer</p>
                        <p>Concealer</p>
                    </div>
                    <div className='modecontent'>
                        <h6>Skincare, Bath & Body</h6>
                        <p>Face Moisturiser</p>
                        <p>Cleanser</p>
                        <p>Masks & Peel</p>
                        <p>Sunscreen</p>
                        <p>Serum</p>
                        <p>Face Wash</p>
                        <p>Lip Balm</p>
                        <p>Body Lotion</p>
                        <p>Body Wash</p>
                        <p>Body serum</p>
                    </div>

                    <div className='modecontent'>
                        <h6>Haircare</h6>
                        <p>Shampoo</p>
                        <p>Conditioner</p>
                        <p>Hair Cream</p>
                        <p>Hair Oil</p>
                        <p>Hair Gel</p>
                        <p>Hair Color</p>
                        <p>Hair Serum</p>
                        <p>Deodorant</p>
                        <p>Perfume</p>
                        <p>Hair Dryer</p>
                    </div>
                    <div className='modecontent'>
                        <h6>Top Brands</h6>
                        <p>Lakme</p>
                        <p>Maybelline</p>
                        <p>Loreal</p>
                        <p>Bath & Body Works</p>
                        <p>THE BODY SHOP</p>
                        <p>Biotique</p>
                        <p>Mamaearth</p>
                        <p>MCaffeine</p>
                        <p>Nivea</p>
                        <p>Concealer</p>
                    </div>
                </Box>
            </Modal>
        </div>
    )
}

export default Beauty